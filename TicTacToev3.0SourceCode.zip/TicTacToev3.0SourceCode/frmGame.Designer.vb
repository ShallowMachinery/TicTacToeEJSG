﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGame
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmGame))
        Me.btnTile01 = New System.Windows.Forms.Button
        Me.btnTile02 = New System.Windows.Forms.Button
        Me.btnTile03 = New System.Windows.Forms.Button
        Me.btnTile04 = New System.Windows.Forms.Button
        Me.btnTile05 = New System.Windows.Forms.Button
        Me.btnTile06 = New System.Windows.Forms.Button
        Me.btnTile07 = New System.Windows.Forms.Button
        Me.btnTile08 = New System.Windows.Forms.Button
        Me.btnTile09 = New System.Windows.Forms.Button
        Me.lblP1Name = New System.Windows.Forms.Label
        Me.lblP1Score = New System.Windows.Forms.Label
        Me.lblP2Score = New System.Windows.Forms.Label
        Me.lblP2Name = New System.Windows.Forms.Label
        Me.btnNewGame = New System.Windows.Forms.Button
        Me.btnMenu = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnTile01
        '
        Me.btnTile01.Location = New System.Drawing.Point(11, 9)
        Me.btnTile01.Name = "btnTile01"
        Me.btnTile01.Size = New System.Drawing.Size(40, 40)
        Me.btnTile01.TabIndex = 0
        Me.btnTile01.UseVisualStyleBackColor = True
        '
        'btnTile02
        '
        Me.btnTile02.Location = New System.Drawing.Point(57, 9)
        Me.btnTile02.Name = "btnTile02"
        Me.btnTile02.Size = New System.Drawing.Size(40, 40)
        Me.btnTile02.TabIndex = 1
        Me.btnTile02.UseVisualStyleBackColor = True
        '
        'btnTile03
        '
        Me.btnTile03.Location = New System.Drawing.Point(103, 9)
        Me.btnTile03.Name = "btnTile03"
        Me.btnTile03.Size = New System.Drawing.Size(40, 40)
        Me.btnTile03.TabIndex = 2
        Me.btnTile03.UseVisualStyleBackColor = True
        '
        'btnTile04
        '
        Me.btnTile04.Location = New System.Drawing.Point(11, 55)
        Me.btnTile04.Name = "btnTile04"
        Me.btnTile04.Size = New System.Drawing.Size(40, 40)
        Me.btnTile04.TabIndex = 3
        Me.btnTile04.UseVisualStyleBackColor = True
        '
        'btnTile05
        '
        Me.btnTile05.Location = New System.Drawing.Point(57, 55)
        Me.btnTile05.Name = "btnTile05"
        Me.btnTile05.Size = New System.Drawing.Size(40, 40)
        Me.btnTile05.TabIndex = 4
        Me.btnTile05.UseVisualStyleBackColor = True
        '
        'btnTile06
        '
        Me.btnTile06.Location = New System.Drawing.Point(103, 55)
        Me.btnTile06.Name = "btnTile06"
        Me.btnTile06.Size = New System.Drawing.Size(40, 40)
        Me.btnTile06.TabIndex = 5
        Me.btnTile06.UseVisualStyleBackColor = True
        '
        'btnTile07
        '
        Me.btnTile07.Location = New System.Drawing.Point(11, 101)
        Me.btnTile07.Name = "btnTile07"
        Me.btnTile07.Size = New System.Drawing.Size(40, 40)
        Me.btnTile07.TabIndex = 6
        Me.btnTile07.UseVisualStyleBackColor = True
        '
        'btnTile08
        '
        Me.btnTile08.Location = New System.Drawing.Point(57, 101)
        Me.btnTile08.Name = "btnTile08"
        Me.btnTile08.Size = New System.Drawing.Size(40, 40)
        Me.btnTile08.TabIndex = 7
        Me.btnTile08.UseVisualStyleBackColor = True
        '
        'btnTile09
        '
        Me.btnTile09.Location = New System.Drawing.Point(103, 101)
        Me.btnTile09.Name = "btnTile09"
        Me.btnTile09.Size = New System.Drawing.Size(40, 40)
        Me.btnTile09.TabIndex = 8
        Me.btnTile09.UseVisualStyleBackColor = True
        '
        'lblP1Name
        '
        Me.lblP1Name.AutoSize = True
        Me.lblP1Name.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblP1Name.ForeColor = System.Drawing.Color.Magenta
        Me.lblP1Name.Location = New System.Drawing.Point(162, 15)
        Me.lblP1Name.Name = "lblP1Name"
        Me.lblP1Name.Size = New System.Drawing.Size(0, 24)
        Me.lblP1Name.TabIndex = 9
        '
        'lblP1Score
        '
        Me.lblP1Score.AutoSize = True
        Me.lblP1Score.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblP1Score.Location = New System.Drawing.Point(328, 15)
        Me.lblP1Score.Name = "lblP1Score"
        Me.lblP1Score.Size = New System.Drawing.Size(21, 24)
        Me.lblP1Score.TabIndex = 10
        Me.lblP1Score.Text = "0"
        '
        'lblP2Score
        '
        Me.lblP2Score.AutoSize = True
        Me.lblP2Score.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblP2Score.Location = New System.Drawing.Point(328, 55)
        Me.lblP2Score.Name = "lblP2Score"
        Me.lblP2Score.Size = New System.Drawing.Size(21, 24)
        Me.lblP2Score.TabIndex = 12
        Me.lblP2Score.Text = "0"
        '
        'lblP2Name
        '
        Me.lblP2Name.AutoSize = True
        Me.lblP2Name.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblP2Name.Location = New System.Drawing.Point(162, 55)
        Me.lblP2Name.Name = "lblP2Name"
        Me.lblP2Name.Size = New System.Drawing.Size(0, 24)
        Me.lblP2Name.TabIndex = 11
        '
        'btnNewGame
        '
        Me.btnNewGame.Location = New System.Drawing.Point(166, 104)
        Me.btnNewGame.Name = "btnNewGame"
        Me.btnNewGame.Size = New System.Drawing.Size(92, 37)
        Me.btnNewGame.TabIndex = 13
        Me.btnNewGame.Text = "btnNewGame"
        Me.btnNewGame.UseVisualStyleBackColor = True
        '
        'btnMenu
        '
        Me.btnMenu.Location = New System.Drawing.Point(264, 104)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(92, 37)
        Me.btnMenu.TabIndex = 14
        Me.btnMenu.Text = "btnMenu"
        Me.btnMenu.UseVisualStyleBackColor = True
        '
        'frmGame
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(361, 153)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnMenu)
        Me.Controls.Add(Me.btnNewGame)
        Me.Controls.Add(Me.lblP2Score)
        Me.Controls.Add(Me.lblP2Name)
        Me.Controls.Add(Me.lblP1Score)
        Me.Controls.Add(Me.lblP1Name)
        Me.Controls.Add(Me.btnTile09)
        Me.Controls.Add(Me.btnTile08)
        Me.Controls.Add(Me.btnTile07)
        Me.Controls.Add(Me.btnTile06)
        Me.Controls.Add(Me.btnTile05)
        Me.Controls.Add(Me.btnTile04)
        Me.Controls.Add(Me.btnTile03)
        Me.Controls.Add(Me.btnTile02)
        Me.Controls.Add(Me.btnTile01)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmGame"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmGame"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnTile01 As System.Windows.Forms.Button
    Friend WithEvents btnTile02 As System.Windows.Forms.Button
    Friend WithEvents btnTile03 As System.Windows.Forms.Button
    Friend WithEvents btnTile04 As System.Windows.Forms.Button
    Friend WithEvents btnTile05 As System.Windows.Forms.Button
    Friend WithEvents btnTile06 As System.Windows.Forms.Button
    Friend WithEvents btnTile07 As System.Windows.Forms.Button
    Friend WithEvents btnTile08 As System.Windows.Forms.Button
    Friend WithEvents btnTile09 As System.Windows.Forms.Button
    Friend WithEvents lblP1Name As System.Windows.Forms.Label
    Friend WithEvents lblP1Score As System.Windows.Forms.Label
    Friend WithEvents lblP2Score As System.Windows.Forms.Label
    Friend WithEvents lblP2Name As System.Windows.Forms.Label
    Friend WithEvents btnNewGame As System.Windows.Forms.Button
    Friend WithEvents btnMenu As System.Windows.Forms.Button
End Class
