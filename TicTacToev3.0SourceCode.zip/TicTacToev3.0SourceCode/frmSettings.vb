﻿Public Class frmSettings
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Hide()
        frmGame.lblP1Name.Text = txtP1Name.Text
        frmGame.lblP2Name.Text = txtP2Name.Text
        If cboCtrgames.Text = "Unlimited" Then
            cboCtrgames.Text = 32767
        End If
        Call frmLangSelect.LangSel()
    End Sub
    Private Sub btnLangSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLangSelect.Click
        Hide()
        frmLangSelect.Show()
    End Sub
    Private Sub frmSettings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If cboCtrgames.Text = "" Then
            cboCtrgames.Text = "Unlimited"
        End If
    End Sub
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNightMode.CheckedChanged
        If chkNightMode.CheckState = CheckState.Checked Then
            Call NightMode.Checked()
        Else
            Call NightMode.Unchecked()
        End If
    End Sub
End Class