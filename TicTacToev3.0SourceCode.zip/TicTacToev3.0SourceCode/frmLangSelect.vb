﻿Public Class frmLangSelect
    Dim Language As String
    Public Sub frmLangSelect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call LangSel()
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If cboLang.Text = "" Then
            MsgBox("No language selected. Please choose one.", MsgBoxStyle.Critical, "Error")
        End If
        If cboLang.Text = "English" Or cboLang.Text = "Filipino" Then
            btnExit.Enabled = False
            Hide()
            frmTitleScreen.Show()
        End If
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
    Public Sub LanguageName()
        Language = cboLang.Text
    End Sub
    Public Sub LangSel()
        If cboLang.Text = "English" Then
            Call English.EN()
        ElseIf cboLang.Text = "Filipino" Then
            Call Filipino.TL()
        End If
    End Sub
    Private Sub cboLang_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboLang.SelectedIndexChanged
        If cboLang.Text = "English" Then
            Call English.EN()
        ElseIf cboLang.Text = "Filipino" Then
            Call Filipino.TL()
        End If
    End Sub
End Class