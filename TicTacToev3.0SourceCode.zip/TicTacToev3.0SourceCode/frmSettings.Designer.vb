﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSettings))
        Me.lblP1Name = New System.Windows.Forms.Label
        Me.lblGameLimit = New System.Windows.Forms.Label
        Me.txtP1Name = New System.Windows.Forms.TextBox
        Me.txtP2Name = New System.Windows.Forms.TextBox
        Me.btnOK = New System.Windows.Forms.Button
        Me.lblGames = New System.Windows.Forms.Label
        Me.cboCtrgames = New System.Windows.Forms.ComboBox
        Me.btnLangSelect = New System.Windows.Forms.Button
        Me.lblP2Name = New System.Windows.Forms.Label
        Me.chkNightMode = New System.Windows.Forms.CheckBox
        Me.chkSound = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'lblP1Name
        '
        Me.lblP1Name.AutoSize = True
        Me.lblP1Name.Location = New System.Drawing.Point(2, 14)
        Me.lblP1Name.Name = "lblP1Name"
        Me.lblP1Name.Size = New System.Drawing.Size(58, 13)
        Me.lblP1Name.TabIndex = 0
        Me.lblP1Name.Text = "lblP1Name"
        Me.lblP1Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblGameLimit
        '
        Me.lblGameLimit.AutoSize = True
        Me.lblGameLimit.Location = New System.Drawing.Point(237, 14)
        Me.lblGameLimit.Name = "lblGameLimit"
        Me.lblGameLimit.Size = New System.Drawing.Size(66, 13)
        Me.lblGameLimit.TabIndex = 2
        Me.lblGameLimit.Text = "lblGameLimit"
        '
        'txtP1Name
        '
        Me.txtP1Name.Location = New System.Drawing.Point(66, 11)
        Me.txtP1Name.Name = "txtP1Name"
        Me.txtP1Name.Size = New System.Drawing.Size(165, 20)
        Me.txtP1Name.TabIndex = 3
        '
        'txtP2Name
        '
        Me.txtP2Name.Location = New System.Drawing.Point(66, 44)
        Me.txtP2Name.Name = "txtP2Name"
        Me.txtP2Name.Size = New System.Drawing.Size(165, 20)
        Me.txtP2Name.TabIndex = 4
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(332, 86)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(54, 20)
        Me.btnOK.TabIndex = 6
        Me.btnOK.Text = "btnOK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'lblGames
        '
        Me.lblGames.AutoSize = True
        Me.lblGames.Location = New System.Drawing.Point(337, 15)
        Me.lblGames.Name = "lblGames"
        Me.lblGames.Size = New System.Drawing.Size(50, 13)
        Me.lblGames.TabIndex = 7
        Me.lblGames.Text = "lblGames"
        '
        'cboCtrgames
        '
        Me.cboCtrgames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCtrgames.FormattingEnabled = True
        Me.cboCtrgames.Items.AddRange(New Object() {"3", "5", "7", "10", "Unlimited"})
        Me.cboCtrgames.Location = New System.Drawing.Point(302, 11)
        Me.cboCtrgames.Name = "cboCtrgames"
        Me.cboCtrgames.Size = New System.Drawing.Size(34, 21)
        Me.cboCtrgames.TabIndex = 8
        '
        'btnLangSelect
        '
        Me.btnLangSelect.Location = New System.Drawing.Point(198, 86)
        Me.btnLangSelect.Name = "btnLangSelect"
        Me.btnLangSelect.Size = New System.Drawing.Size(128, 20)
        Me.btnLangSelect.TabIndex = 9
        Me.btnLangSelect.Text = "btnLangSelect"
        Me.btnLangSelect.UseVisualStyleBackColor = True
        '
        'lblP2Name
        '
        Me.lblP2Name.AutoSize = True
        Me.lblP2Name.Location = New System.Drawing.Point(2, 47)
        Me.lblP2Name.Name = "lblP2Name"
        Me.lblP2Name.Size = New System.Drawing.Size(58, 13)
        Me.lblP2Name.TabIndex = 10
        Me.lblP2Name.Text = "lblP2Name"
        Me.lblP2Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chkNightMode
        '
        Me.chkNightMode.AutoSize = True
        Me.chkNightMode.BackColor = System.Drawing.Color.White
        Me.chkNightMode.Location = New System.Drawing.Point(240, 43)
        Me.chkNightMode.Name = "chkNightMode"
        Me.chkNightMode.Size = New System.Drawing.Size(96, 17)
        Me.chkNightMode.TabIndex = 11
        Me.chkNightMode.Text = "chkNightMode"
        Me.chkNightMode.UseVisualStyleBackColor = False
        '
        'chkSound
        '
        Me.chkSound.AutoSize = True
        Me.chkSound.BackColor = System.Drawing.Color.White
        Me.chkSound.Location = New System.Drawing.Point(240, 63)
        Me.chkSound.Name = "chkSound"
        Me.chkSound.Size = New System.Drawing.Size(75, 17)
        Me.chkSound.TabIndex = 12
        Me.chkSound.Text = "chkSound"
        Me.chkSound.UseVisualStyleBackColor = False
        '
        'frmSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(389, 109)
        Me.ControlBox = False
        Me.Controls.Add(Me.chkSound)
        Me.Controls.Add(Me.chkNightMode)
        Me.Controls.Add(Me.lblP2Name)
        Me.Controls.Add(Me.btnLangSelect)
        Me.Controls.Add(Me.cboCtrgames)
        Me.Controls.Add(Me.lblGames)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtP2Name)
        Me.Controls.Add(Me.txtP1Name)
        Me.Controls.Add(Me.lblGameLimit)
        Me.Controls.Add(Me.lblP1Name)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmSettings"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmSettingsScreen"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblP1Name As System.Windows.Forms.Label
    Friend WithEvents lblGameLimit As System.Windows.Forms.Label
    Friend WithEvents txtP1Name As System.Windows.Forms.TextBox
    Friend WithEvents txtP2Name As System.Windows.Forms.TextBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents lblGames As System.Windows.Forms.Label
    Friend WithEvents cboCtrgames As System.Windows.Forms.ComboBox
    Friend WithEvents btnLangSelect As System.Windows.Forms.Button
    Friend WithEvents lblP2Name As System.Windows.Forms.Label
    Friend WithEvents chkNightMode As System.Windows.Forms.CheckBox
    Friend WithEvents chkSound As System.Windows.Forms.CheckBox
End Class
