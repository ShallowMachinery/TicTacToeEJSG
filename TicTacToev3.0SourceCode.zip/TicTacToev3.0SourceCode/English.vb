﻿Module English
    Public Sub EN()
        'frmlangSelect
        frmLangSelect.Text = "Select Language"
        frmLangSelect.lblLangSelect.Text = "Select Language:"
        frmLangSelect.cboLang.Text = "English"
        frmLangSelect.btnSave.Text = "Save"
        frmLangSelect.btnExit.Text = "Exit"
        'frmTitleScreen
        frmTitleScreen.Text = "Tic-Tac-Toe"
        frmTitleScreen.lblProductName.Text = "Tic-Tac-Toe"
        frmTitleScreen.btnPlay.Text = "Play"
        frmTitleScreen.btnSettings.Text = "Settings"
        frmTitleScreen.btnAbout.Text = "About"
        frmTitleScreen.btnExit.Text = "Exit"
        'frmAboutScreen
        frmAboutScreen.Text = "About the Program"
        frmAboutScreen.lblProdName.Text = "Tic-Tac-Toe"
        frmAboutScreen.lblVersion.Text = "Version 3.0"
        frmAboutScreen.lblCopyright.Text = "Eleazar Galope, © 2019"
        frmAboutScreen.btnOK.Text = "OK"
        'frmSettings
        frmSettings.Text = "Settings"
        frmSettings.chkNightMode.Text = "Night Mode"
        frmSettings.lblP1Name.Text = "Player 1:"
        frmSettings.lblP2Name.Text = "Player 2:"
        frmSettings.lblGameLimit.Text = "Limit:"
        frmSettings.lblGames.Text = "game(s)"
        frmSettings.btnLangSelect.Text = "Select Language"
        frmSettings.btnOK.Text = "OK"
        frmSettings.chkSound.Text = "Sound Effects"
        'dlgNewGame
        dlgNewGame.Text = "Start New Game"
        dlgNewGame.lblNewGame.Text = "There is unsaved game. Do you want to start a new game instead?"
        dlgNewGame.btnYes.Text = "Yes"
        dlgNewGame.btnNo.Text = "No"
        'frmGame
        If frmSettings.txtP1Name.Text = "" Then
            frmGame.lblP1Name.Text = "Player 1"
        End If
        If frmSettings.txtP2Name.Text = "" Then
            frmGame.lblP2Name.Text = "Player 2"
        End If
        frmGame.Text = "Game"
        frmGame.btnNewGame.Text = "New Game"
        frmGame.btnMenu.Text = "Back to Menu"
        'dlgWin2
        dlgWin2.btnOK.Text = "OK"
        Call dlgWin_EN()
    End Sub
    Public Sub Limit_EN()
        If frmGame.lblP1Score.Text = frmSettings.cboCtrgames.Text Then
            MsgBox(frmGame.lblP1Name.Text + " reaches the limit. " + frmGame.lblP1Name.Text + " wins the match! The scores will be reset.", , frmGame.lblP1Name.Text + " reaches the limit.")
        ElseIf frmGame.lblP2Score.Text = frmSettings.cboCtrgames.Text Then
            MsgBox(frmGame.lblP2Name.Text + " reaches the limit. " + frmGame.lblP2Name.Text + " wins the match! The scores will be reset.", , frmGame.lblP2Name.Text + " reaches the limit.")
        End If
        Call frmGame.NewGameAfterLimit()
    End Sub
    Public Sub dlgWin_EN()
        'Game Logic
        If frmGame.btnTile01.Text = "X" And frmGame.btnTile02.Text = "X" And frmGame.btnTile03.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile04.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile06.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile07.Text = "X" And frmGame.btnTile08.Text = "X" And frmGame.btnTile09.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "X" And frmGame.btnTile04.Text = "X" And frmGame.btnTile07.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile02.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile08.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "X" And frmGame.btnTile06.Text = "X" And frmGame.btnTile09.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile08.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile07.Text = "X" Then
            dlgWin2.Text = frmGame.lblP1Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP1Name.Text + " wins. " + frmGame.lblP1Name.Text + "'s score is now " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "O" And frmGame.btnTile02.Text = "O" And frmGame.btnTile03.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile04.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile06.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile07.Text = "O" And frmGame.btnTile08.Text = "O" And frmGame.btnTile09.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "O" And frmGame.btnTile04.Text = "O" And frmGame.btnTile07.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile02.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile08.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "O" And frmGame.btnTile06.Text = "O" And frmGame.btnTile09.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile08.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile07.Text = "O" Then
            dlgWin2.Text = frmGame.lblP2Name.Text + " wins!"
            dlgWin2.lblWin.Text = frmGame.lblP2Name.Text + " wins. " + frmGame.lblP2Name.Text + "'s score is now " + frmGame.lblP2Score.Text + "."
        End If
    End Sub
End Module
