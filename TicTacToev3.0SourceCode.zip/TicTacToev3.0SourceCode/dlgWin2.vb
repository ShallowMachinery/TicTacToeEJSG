﻿Public Class dlgWin2

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Hide()
    End Sub
End Class