﻿Module Filipino
    Public Sub TL()
        'frmlangSelect
        frmLangSelect.Text = "Pumili ng wika"
        frmLangSelect.lblLangSelect.Text = "Pumili ng wika:"
        frmLangSelect.cboLang.Text = "Filipino"
        frmLangSelect.btnSave.Text = "I-save"
        frmLangSelect.btnExit.Text = "Lumabas"
        'frmTitleScreen
        frmTitleScreen.Text = "Tic-Tac-Toe"
        frmTitleScreen.lblProductName.Text = "Tic-Tac-Toe"
        frmTitleScreen.btnPlay.Text = "Maglaro"
        frmTitleScreen.btnSettings.Text = "Pag-aayos"
        frmTitleScreen.btnAbout.Text = "Tungkol"
        frmTitleScreen.btnExit.Text = "Lumabas"
        'frmAboutScreen
        frmAboutScreen.Text = "Tungkol sa Aplikasyon"
        frmAboutScreen.lblProdName.Text = "Tic-Tac-Toe"
        frmAboutScreen.lblVersion.Text = "Version 3.0"
        frmAboutScreen.lblCopyright.Text = "Eleazar Galope, © 2019"
        frmAboutScreen.btnOK.Text = "OK"
        'frmSettings
        frmSettings.Text = "Pag-aayos"
        frmSettings.chkNightMode.Text = "Modo na pang-gabi"
        frmSettings.lblP1Name.Text = "Manlalaro 1:"
        frmSettings.lblP2Name.Text = "Manlalaro 2:"
        frmSettings.lblGameLimit.Text = "Hanggang:"
        frmSettings.lblGames.Text = "(mga) laro"
        frmSettings.btnLangSelect.Text = "Pumili ng wika"
        frmSettings.btnOK.Text = "OK"
        frmSettings.chkSound.Text = "Tunog"
        'dlgNewGame
        dlgNewGame.Text = "Magsimula ng bagong laro"
        dlgNewGame.lblNewGame.Text = "Mayroong laro sa kasalukuyan na hindi pa natatapos. Gusto mo pa rin bang magsimula ng bagong laro?"
        dlgNewGame.btnYes.Text = "Oo"
        dlgNewGame.btnNo.Text = "Hindi"
        'frmGame
        If frmSettings.txtP1Name.Text = "" Then
            frmGame.lblP1Name.Text = "Manlalaro 1"
        End If
        If frmSettings.txtP2Name.Text = "" Then
            frmGame.lblP2Name.Text = "Manlalaro 2"
        End If
        frmGame.Text = "Laro"
        frmGame.btnNewGame.Text = "Bagong Laro"
        frmGame.btnMenu.Text = "Bumalik sa Menu"
        'dlgWin2
        dlgWin2.btnOK.Text = "OK"
        Call dlgWin_TL()
    End Sub
    Public Sub Limit_TL()
        If frmGame.lblP1Score.Text = frmSettings.cboCtrgames.Text Then
            MsgBox("Si " + frmGame.lblP1Name.Text + " ay naabot na ang hangganan. Nanalo si " + frmGame.lblP1Name.Text + " sa laro! Marereset ang mga scores.", , "Si " + frmGame.lblP1Name.Text + " ay naabot na ang hangganan.")
        ElseIf frmGame.lblP2Score.Text = frmSettings.cboCtrgames.Text Then
            MsgBox("Si " + frmGame.lblP2Name.Text + " ay naabot na ang hangganan. Nanalo si " + frmGame.lblP2Name.Text + " sa laro! Marereset ang mga scores.", , "Si " + frmGame.lblP2Name.Text + " ay naabot na ang hangganan.")
        End If
        Call frmGame.NewGameAfterLimit()
    End Sub
    Public Sub dlgWin_TL()
        'Game Logic
        If frmGame.btnTile01.Text = "X" And frmGame.btnTile02.Text = "X" And frmGame.btnTile03.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile04.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile06.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile07.Text = "X" And frmGame.btnTile08.Text = "X" And frmGame.btnTile09.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "X" And frmGame.btnTile04.Text = "X" And frmGame.btnTile07.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile02.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile08.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "X" And frmGame.btnTile06.Text = "X" And frmGame.btnTile09.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile08.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "X" And frmGame.btnTile05.Text = "X" And frmGame.btnTile07.Text = "X" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP1Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP1Name.Text + ". Ang score ngayon ni " + frmGame.lblP1Name.Text + " ay " + frmGame.lblP1Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "O" And frmGame.btnTile02.Text = "O" And frmGame.btnTile03.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile04.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile06.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile07.Text = "O" And frmGame.btnTile08.Text = "O" And frmGame.btnTile09.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "O" And frmGame.btnTile04.Text = "O" And frmGame.btnTile07.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile02.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile08.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "O" And frmGame.btnTile06.Text = "O" And frmGame.btnTile09.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile01.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile08.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
        If frmGame.btnTile03.Text = "O" And frmGame.btnTile05.Text = "O" And frmGame.btnTile07.Text = "O" Then
            dlgWin2.Text = "Nanalo si " + frmGame.lblP2Name.Text + "!"
            dlgWin2.lblWin.Text = "Nanalo si " + frmGame.lblP2Name.Text + ". Ang score ngayon ni " + frmGame.lblP2Name.Text + " ay " + frmGame.lblP2Score.Text + "."
        End If
    End Sub
End Module
