﻿Public Class frmTitleScreen
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
    Private Sub btnPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlay.Click
        If frmGame.lblP1Score.Text >= 1 Then
            dlgNewGame.Show()
        ElseIf frmGame.lblP2Score.Text >= 1 Then
            dlgNewGame.Show()
        End If
        If frmGame.lblP1Score.Text = 0 And frmGame.lblP2Score.Text = 0 Then
            frmGame.Show()
            Hide()
            frmGame.btnTile01.Text = ""
            frmGame.btnTile02.Text = ""
            frmGame.btnTile03.Text = ""
            frmGame.btnTile04.Text = ""
            frmGame.btnTile05.Text = ""
            frmGame.btnTile06.Text = ""
            frmGame.btnTile07.Text = ""
            frmGame.btnTile08.Text = ""
            frmGame.btnTile09.Text = ""
            frmGame.btnTile01.Enabled = True
            frmGame.btnTile02.Enabled = True
            frmGame.btnTile03.Enabled = True
            frmGame.btnTile04.Enabled = True
            frmGame.btnTile05.Enabled = True
            frmGame.btnTile06.Enabled = True
            frmGame.btnTile07.Enabled = True
            frmGame.btnTile08.Enabled = True
            frmGame.btnTile09.Enabled = True
        End If
    End Sub
    Private Sub btnSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSettings.Click
        frmSettings.Show()
    End Sub

    Private Sub btnAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAbout.Click
        Hide()
        frmAboutScreen.Show()
    End Sub
End Class
