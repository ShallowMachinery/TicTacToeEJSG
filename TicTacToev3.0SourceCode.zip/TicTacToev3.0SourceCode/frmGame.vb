﻿Public Class frmGame
    Dim Point As Boolean
    Private Sub btnNewGame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewGame.Click
        btnTile01.Text = ""
        btnTile02.Text = ""
        btnTile03.Text = ""
        btnTile04.Text = ""
        btnTile05.Text = ""
        btnTile06.Text = ""
        btnTile07.Text = ""
        btnTile08.Text = ""
        btnTile09.Text = ""
        btnTile01.Enabled = True
        btnTile02.Enabled = True
        btnTile03.Enabled = True
        btnTile04.Enabled = True
        btnTile05.Enabled = True
        btnTile06.Enabled = True
        btnTile07.Enabled = True
        btnTile08.Enabled = True
        btnTile09.Enabled = True
    End Sub
    Private Sub btnMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenu.Click
        frmTitleScreen.Show()
        Hide()
    End Sub
    Private Sub btnTile01_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile01.Click
        If Point = False Then
            btnTile01.Text = "X"
            Point = True
        Else
            btnTile01.Text = "O"
            Point = False
        End If
        btnTile01.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile02_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile02.Click
        If Point = False Then
            btnTile02.Text = "X"
            Point = True
        Else
            btnTile02.Text = "O"
            Point = False
        End If
        btnTile02.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile03_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile03.Click
        If Point = False Then
            btnTile03.Text = "X"
            Point = True
        Else
            btnTile03.Text = "O"
            Point = False
        End If
        btnTile03.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile04_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile04.Click
        If Point = False Then
            btnTile04.Text = "X"
            Point = True
        Else
            btnTile04.Text = "O"
            Point = False
        End If
        btnTile04.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile05_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile05.Click
        If Point = False Then
            btnTile05.Text = "X"
            Point = True
        Else
            btnTile05.Text = "O"
            Point = False
        End If
        btnTile05.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile06_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile06.Click
        If Point = False Then
            btnTile06.Text = "X"
            Point = True
        Else
            btnTile06.Text = "O"
            Point = False
        End If
        btnTile06.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile07_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile07.Click
        If Point = False Then
            btnTile07.Text = "X"
            Point = True
        Else
            btnTile07.Text = "O"
            Point = False
        End If
        btnTile07.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile08_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile08.Click
        If Point = False Then
            btnTile08.Text = "X"
            Point = True
        Else
            btnTile08.Text = "O"
            Point = False
        End If
        btnTile08.Enabled = False
        Call addpoint()
    End Sub
    Private Sub btnTile09_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTile09.Click
        If Point = False Then
            btnTile09.Text = "X"
            Point = True
        Else
            btnTile09.Text = "O"
            Point = False
        End If
        btnTile09.Enabled = False
        Call addpoint()
    End Sub
    Private Sub addpoint()
        If Point = True Then
            lblP2Name.ForeColor = Color.Magenta
            lblP1Name.ForeColor = Color.Black
        Else
            lblP1Name.ForeColor = Color.Magenta
            lblP2Name.ForeColor = Color.Black
        End If
        If btnTile01.Text = "X" And btnTile02.Text = "X" And btnTile03.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile04.Text = "X" And btnTile05.Text = "X" And btnTile06.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile07.Text = "X" And btnTile08.Text = "X" And btnTile09.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile01.Text = "X" And btnTile04.Text = "X" And btnTile07.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile02.Text = "X" And btnTile05.Text = "X" And btnTile08.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile03.Text = "X" And btnTile06.Text = "X" And btnTile09.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile01.Text = "X" And btnTile05.Text = "X" And btnTile08.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile03.Text = "X" And btnTile05.Text = "X" And btnTile07.Text = "X" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile01.Text = "O" And btnTile02.Text = "O" And btnTile03.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile04.Text = "O" And btnTile05.Text = "O" And btnTile06.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile07.Text = "O" And btnTile08.Text = "O" And btnTile09.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile01.Text = "O" And btnTile04.Text = "O" And btnTile07.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile02.Text = "O" And btnTile05.Text = "O" And btnTile08.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile03.Text = "O" And btnTile06.Text = "O" And btnTile09.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile01.Text = "O" And btnTile05.Text = "O" And btnTile08.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
        If btnTile03.Text = "O" And btnTile05.Text = "O" And btnTile07.Text = "O" Then
            Call dlgWin3()
            dlgWin2.Show()
            Call disable()
        End If
    End Sub
    Private Sub disable()
        btnTile01.Enabled = False
        btnTile02.Enabled = False
        btnTile03.Enabled = False
        btnTile04.Enabled = False
        btnTile05.Enabled = False
        btnTile06.Enabled = False
        btnTile07.Enabled = False
        btnTile08.Enabled = False
        btnTile09.Enabled = False
    End Sub
    Public Sub NewGameAfterLimit()
        If lblP1Score.Text = frmSettings.cboCtrgames.Text Then
            Call NG()
        ElseIf lblP2Score.Text = frmSettings.cboCtrgames.Text Then
            Call NG()
        End If
    End Sub
    Private Sub NG()
        btnTile01.Text = ""
        btnTile02.Text = ""
        btnTile03.Text = ""
        btnTile04.Text = ""
        btnTile05.Text = ""
        btnTile06.Text = ""
        btnTile07.Text = ""
        btnTile08.Text = ""
        btnTile09.Text = ""
        btnTile01.Enabled = True
        btnTile02.Enabled = True
        btnTile03.Enabled = True
        btnTile04.Enabled = True
        btnTile05.Enabled = True
        btnTile06.Enabled = True
        btnTile07.Enabled = True
        btnTile08.Enabled = True
        btnTile09.Enabled = True
        lblP1Score.Text = "0"
        lblP2Score.Text = "0"
    End Sub
    Public Sub dlgWin3()
        If btnTile01.Text = "X" And btnTile02.Text = "X" And btnTile03.Text = "X" Then
            lblP1Score.Text = lblP1Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile04.Text = "X" And btnTile05.Text = "X" And btnTile06.Text = "X" Then
            Call dlgWin3_Lang()
        End If
        If btnTile07.Text = "X" And btnTile08.Text = "X" And btnTile09.Text = "X" Then
            lblP1Score.Text = lblP1Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile01.Text = "X" And btnTile04.Text = "X" And btnTile07.Text = "X" Then
            lblP1Score.Text = lblP1Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile02.Text = "X" And btnTile05.Text = "X" And btnTile08.Text = "X" Then
            lblP1Score.Text = lblP1Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile03.Text = "X" And btnTile06.Text = "X" And btnTile09.Text = "X" Then
            lblP1Score.Text = lblP1Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile01.Text = "X" And btnTile05.Text = "X" And btnTile08.Text = "X" Then
            lblP1Score.Text = lblP1Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile03.Text = "X" And btnTile05.Text = "X" And btnTile07.Text = "X" Then
            lblP1Score.Text = lblP1Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile01.Text = "O" And btnTile02.Text = "O" And btnTile03.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile04.Text = "O" And btnTile05.Text = "O" And btnTile06.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile07.Text = "O" And btnTile08.Text = "O" And btnTile09.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile01.Text = "O" And btnTile04.Text = "O" And btnTile07.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile02.Text = "O" And btnTile05.Text = "O" And btnTile08.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile03.Text = "O" And btnTile06.Text = "O" And btnTile09.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile01.Text = "O" And btnTile05.Text = "O" And btnTile08.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
        If btnTile03.Text = "O" And btnTile05.Text = "O" And btnTile07.Text = "O" Then
            lblP2Score.Text = lblP2Score.Text + 1
            Call dlgWin3_Lang()
        End If
    End Sub
    Public Sub dlgWin3_Lang()
        If frmLangSelect.cboLang.Text = "English" Then
            Call dlgWin_EN()
            Call Limit_EN()
        ElseIf frmLangSelect.cboLang.Text = "Filipino" Then
            Call dlgWin_TL()
            Call Limit_TL()
        End If
    End Sub
End Class
