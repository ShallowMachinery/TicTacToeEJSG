﻿Module NightMode
    Public Sub Checked()
        'dlgNewGame
        dlgNewGame.BackColor = Color.DarkGray
        dlgNewGame.ForeColor = Color.GhostWhite
        'dlgWin2
        dlgWin2.BackColor = Color.DarkGray
        dlgWin2.ForeColor = Color.GhostWhite
        'frmAboutScreen
        frmAboutScreen.BackColor = Color.DarkGray
        frmAboutScreen.ForeColor = Color.GhostWhite
        'frmGame
        frmGame.BackColor = Color.DarkGray
        'frmLangSelect
        frmLangSelect.BackColor = Color.DarkGray
        frmLangSelect.ForeColor = Color.GhostWhite
        'frmSettings
        frmSettings.BackColor = Color.DarkGray
        frmSettings.ForeColor = Color.GhostWhite
        frmSettings.btnLangSelect.ForeColor = Color.Black
        frmSettings.btnOK.ForeColor = Color.Black
        frmSettings.chkNightMode.BackColor = Color.DarkGray
        frmSettings.chkSound.BackColor = Color.DarkGray
        'frmTitleScreen
        frmTitleScreen.BackColor = Color.DarkGray
        frmTitleScreen.lblProductName.ForeColor = Color.GhostWhite
    End Sub
    Public Sub Unchecked()
        'dlgNewGame
        dlgNewGame.BackColor = Color.White
        dlgNewGame.ForeColor = Color.Black
        'dlgWin2
        dlgWin2.BackColor = Color.White
        dlgWin2.ForeColor = Color.Black
        'frmAboutScreen
        frmAboutScreen.BackColor = Color.White
        frmAboutScreen.ForeColor = Color.Black
        'frmGame
        frmGame.BackColor = Color.White
        'frmLangSelect
        frmLangSelect.BackColor = Color.White
        frmLangSelect.ForeColor = Color.Black
        'frmSettings
        frmSettings.BackColor = Color.White
        frmSettings.ForeColor = Color.Black
        frmSettings.btnLangSelect.ForeColor = Color.Black
        frmSettings.btnOK.ForeColor = Color.Black
        frmSettings.chkNightMode.BackColor = Color.White
        frmSettings.chkSound.BackColor = Color.White
        'frmTitleScreen
        frmTitleScreen.BackColor = Color.White
        frmTitleScreen.lblProductName.ForeColor = Color.Black
    End Sub
End Module
