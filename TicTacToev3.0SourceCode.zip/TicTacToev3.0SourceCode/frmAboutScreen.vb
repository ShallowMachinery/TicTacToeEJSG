﻿Public NotInheritable Class frmAboutScreen
    Dim Website As String = "http://tictactoeejsg.6te.net"

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Hide()
        frmTitleScreen.Show()
    End Sub

    Private Sub frmAboutScreen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblWebsite.Text = Website
    End Sub

    Private Sub lblWebsite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblWebsite.Click
        System.Diagnostics.Process.Start(Website)
    End Sub
End Class
