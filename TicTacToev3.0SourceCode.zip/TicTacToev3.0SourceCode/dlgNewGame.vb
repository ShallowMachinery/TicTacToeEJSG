﻿Public Class dlgNewGame

    Private Sub btnYes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnYes.Click
        frmGame.lblP1Score.Text = "0"
        frmGame.lblP2Score.Text = "0"
        frmGame.btnTile01.Text = ""
        frmGame.btnTile02.Text = ""
        frmGame.btnTile03.Text = ""
        frmGame.btnTile04.Text = ""
        frmGame.btnTile05.Text = ""
        frmGame.btnTile06.Text = ""
        frmGame.btnTile07.Text = ""
        frmGame.btnTile08.Text = ""
        frmGame.btnTile09.Text = ""
        frmGame.btnTile01.Enabled = True
        frmGame.btnTile02.Enabled = True
        frmGame.btnTile03.Enabled = True
        frmGame.btnTile04.Enabled = True
        frmGame.btnTile05.Enabled = True
        frmGame.btnTile06.Enabled = True
        frmGame.btnTile07.Enabled = True
        frmGame.btnTile08.Enabled = True
        frmGame.btnTile09.Enabled = True
        Hide()
        frmGame.Show()
    End Sub
    Private Sub btnNo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNo.Click
        Hide()
        frmGame.Show()
    End Sub
End Class